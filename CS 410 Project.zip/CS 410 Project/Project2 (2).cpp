#include <iostream>
#include <string>

using namespace std;

/*

SNHU Investments – Client Management System
Project Two – Security Review Version
Author: Reginald True


This file includes:
- Security problems clearly marked
- Fixes inside main()
- Notes explaining what cannot be fully fixed here

*/



// V-02: Permission Problem
// The old code trusted what the user typed as permission.
// If someone typed the right number, they got access.
// That is not safe.
// FIX: Only allow permission level 1.
// A real fix would require a login system.

bool CheckUserPermissionAccess(int level)
{
    if (level == 1)
        return true;
    else
        return false;
}



// V-03: Fake validation
// This function does not really check anything.
// It just returns the same number.
// This makes it look safe, but it is not.

int ChangeCustomerChoice(int choice)
{
    return choice;
}



// V-04: Information display risk
// This function shows private data.
// It does not check permissions inside the function.
// If another part of the program fails,
// this could show information to the wrong user.

void DisplayInfo()
{
    cout << "Customer Account Balance: $5,000" << endl;
}


int main()
{
    cout << "SNHU Investments Client Management System" << endl;
    cout << "1. View Customer Data" << endl;
    cout << "2. Exit" << endl;

    
    // V-01: Input problem
    // The old code used: cin >> choice;
    // If someone types letters instead of numbers,
    // the program can break or act wrong.
    //
    // FIX: Read input safely and check it.
    

    int choice = 0;
    string input;

    cout << "Enter your choice: ";
    getline(cin, input);

    try
    {
        choice = stoi(input);
    }
    catch (...)
    {
        cout << "Invalid input. Please enter a number." << endl;
        return 1;
    }

    // FIX: Only allow the choices we expect
    if (choice != 1 && choice != 2)
    {
        cout << "Invalid choice. Please select 1 or 2." << endl;
        return 1;
    }

    // IMPORTANT SECURITY FIX:
    // Do NOT use the user's menu choice as permission.
    // Permission should come from a login system.
    int permissionLevel = 1;  // Example authorized user

    if (choice == 2)
    {
        cout << "Goodbye." << endl;
        return 0;
    }

    if (CheckUserPermissionAccess(permissionLevel))
    {
        DisplayInfo();
    }
    else
    {
        cout << "Access denied." << endl;
    }

    return 0;
}
#include <iostream>
#include <string>

using namespace std;

/*

SNHU Investments – Client Management System
Project Two – Enhanced Security Review Version
Author: Reginald True

This enhanced version improves the original project by:
- breaking the program into smaller functions
- validating input in a safer way
- keeping menu handling separate from permission checks
- making program flow easier to read and test

*/

const int VIEW_CUSTOMER_DATA = 1;
const int EXIT_PROGRAM = 2;
const double CUSTOMER_BALANCE = 5000.00;

// Checks whether the current user has permission to view customer data.
// In this simplified example, only permission level 1 is allowed.
// A real system would use authentication and role-based access control.
bool CheckUserPermissionAccess(int level)
{
    return level == 1;
}

// Confirms that the menu choice is one of the allowed options.
bool IsValidMenuChoice(int choice)
{
    return choice == VIEW_CUSTOMER_DATA || choice == EXIT_PROGRAM;
}

// Displays the customer information.
// This function assumes permission was already checked before it is called.
void DisplayInfo()
{
    cout << "Customer Account Balance: $" << CUSTOMER_BALANCE << endl;
}

// Shows the main menu options.
void DisplayMenu()
{
    cout << "\nSNHU Investments Client Management System" << endl;
    cout << VIEW_CUSTOMER_DATA << ". View Customer Data" << endl;
    cout << EXIT_PROGRAM << ". Exit" << endl;
}

// Reads user input safely and converts it to an integer.
// Returns -1 if the input is not a valid number.
int GetMenuChoice()
{
    string input;

    cout << "Enter your choice: ";
    getline(cin, input);

    try
    {
        return stoi(input);
    }
    catch (...)
    {
        return -1;
    }
}

// Handles the view-customer-data option.
void HandleCustomerData(int permissionLevel)
{
    if (CheckUserPermissionAccess(permissionLevel))
    {
        DisplayInfo();
    }
    else
    {
        cout << "Access denied." << endl;
    }
}

int main()
{
    int permissionLevel = 1;   // Example authorized user
    bool running = true;

    while (running)
    {
        DisplayMenu();
        int choice = GetMenuChoice();

        if (!IsValidMenuChoice(choice))
        {
            cout << "Invalid input. Please select 1 or 2." << endl;
            continue;
        }

        switch (choice)
        {
        case VIEW_CUSTOMER_DATA:
            HandleCustomerData(permissionLevel);
            break;

        case EXIT_PROGRAM:
            cout << "Goodbye." << endl;
            running = false;
            break;
        }
    }

    return 0;
}
